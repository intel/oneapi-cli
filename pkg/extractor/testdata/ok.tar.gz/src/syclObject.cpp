//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include "syclObject.h"

SYCLObj::SYCLObj() : _queue(cl::sycl::default_selector()), _device(_queue.get_device()){}
   
SYCLObj::SYCLObj(int selectedDeviceIndex){
	setUpDevice(selectedDeviceIndex);
   	setUpQueue();
}

SYCLObj::SYCLObj(std::string platform, std::string deviceType){
	setUpDevice(platform, deviceType);
	setUpQueue();
}
    
// Set device by index
void SYCLObj::setUpDevice(int selectedDeviceIndex){
	std::vector<cl::sycl::device> devices = cl::sycl::device::get_devices();
	for(int i = 0; i < devices.size(); i++){
		if(i == selectedDeviceIndex){
#ifdef DEBUG
			std::cout << "[x]" << 
                    devices[i].get_info<cl::sycl::info::device::name>() << std::endl;
#endif
			_device = devices[i];
		}
#ifdef DEBUG
		else
			std::cout << "[" << i << "]" << 
                devices[i].get_info<cl::sycl::info::device::name>() << std::endl;
#endif
	}
}

// Set device by name
void SYCLObj::setUpDevice(std::string platform, std::string deviceType){
	std::vector<cl::sycl::device> devices = cl::sycl::device::get_devices();
	cl::sycl::info::device_type device_type;
	if(deviceType == "cpu") {
		device_type = cl::sycl::info::device_type::cpu;
	} else {
		device_type = cl::sycl::info::device_type::gpu;
	}
	bool deviceChosen = false;

	for(int i = 0; i < devices.size(); i++) {
		if(!deviceChosen 
					&& devices[i].get_platform().get_info<cl::sycl::info::platform::vendor>().find(platform) != std::string::npos 
					&& devices[i].get_info<cl::sycl::info::device::device_type>() == device_type) {
#ifdef DEBUG
			std::cout << "[x]" << 
                devices[i].get_info<cl::sycl::info::device::name>() << std::endl;
#endif
			_device = devices[i];
			deviceChosen = true;
		}
#ifdef DEBUG
		else { 
                std::cout << "[" << i << "]" << 
                    devices[i].get_info<cl::sycl::info::device::name>() << std::endl;
		}
#endif
	}

	if(!deviceChosen) {
		std::cout << "Available devices: \n";
		for(int i = 0; i < devices.size(); i++) {
			std::cout << "[" << i << "]" << "Vendor: " <<
           			devices[i].get_platform().get_info<cl::sycl::info::platform::vendor>() <<"\t" 
                    << " Device: " <<
                    devices[i].get_info<cl::sycl::info::device::name>() << std::endl;
		}
		throw std::runtime_error("Cannot find the specified device.");
	}
}

cl::sycl::queue SYCLObj::setUpQueue(){
	bool error = false;
	unsigned nTimesCall = 0;
	auto asyncHandler = [&error, &nTimesCall](cl::sycl::exception_list eL) {
		++nTimesCall;
		for (auto& e : eL) {
			try {
				std::rethrow_exception(e);
			} catch (cl::sycl::exception& e) {
				error = true;
				std::cout << " I have caught an exception! " << std::endl;
				std::cout << e.what() << std::endl;
			}
		}
	};

   	cl::sycl::property_list propList = cl::sycl::property_list{
				cl::sycl::property::queue::enable_profiling()};
	_queue = cl::sycl::queue(_device, asyncHandler, propList);
   	return _queue;
}

void SYCLObj::showDevice(){
	// Output device and platform information. 
	auto deviceName = _device.get_info<cl::sycl::info::device::name>();
	std::cout << " Device Name: " << deviceName << "\n";
	auto platformName =
			_device.get_platform().get_info<cl::sycl::info::platform::name>();
	std::cout << " Platform Name " << platformName << "\n";
}
