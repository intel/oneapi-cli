//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include "mandelSerial.h"
#include "mandelParallel.h"
#include "cmdoptions.h"
#include "syclObject.h"

int main(int argc, const char *argv[]) {
  
    CmdParserMandelbrot cmdparser(argc, argv);
    cmdparser.parse();

	// Immediatly exit if user wanted to see the usage information only.
	if (cmdparser.help.isSet())
	{
		return 0;
	}
     
	const int ROW_SIZE = 120;
	const int COL_SIZE = 120;
	const int MAX_ITERATIONS = 100;

    SYCLObj syclObj;
    if(cmdparser.validation.isSet())
    {
        MandelSerial mandelSerial(ROW_SIZE, COL_SIZE, MAX_ITERATIONS);   
		mandelSerial.Evaluate();  
		mandelSerial.Print();
    }
   	 
/*    if(cmdparser.device.isSet())
    {
        syclObj.setUpDevice(stoi(cmdparser.device.getValue()));
    }
    else
    {
        syclObj.setUpDevice(cmdparser.platform.getValue(), cmdparser.device_type.getValue());
    }
  */  
    syclObj.setUpQueue(); 

    syclObj.showDevice();
    MandelParallel<ROW_SIZE, COL_SIZE, MAX_ITERATIONS> mandelParallel; 
    mandelParallel.Evaluate(syclObj); 
    mandelParallel.Print();
}
