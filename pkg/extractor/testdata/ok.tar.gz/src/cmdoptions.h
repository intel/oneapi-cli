//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#ifndef _INTEL_OPENCL_SAMPLE_MANDELBROT_CMDOPTIONS_HPP_
#define _INTEL_OPENCL_SAMPLE_MANDELBROT_CMDOPTIONS_HPP_

#include "cmdparser.h"


// All command-line options for GEMM sample
class CmdParserMandelbrot: public CmdParserCommon
{
public:
    // For these options description, please refer to the constructor definition.

    CmdOption<int> inputSize;
    CmdOption<int> iterations;

    CmdOption<bool> validation;

    CmdParserMandelbrot(int argc, const char** argv);
    virtual void parse ();

   

private:

    template <typename T>
    void validatePositiveness (const CmdOption<T>& parameter)
    {
        parameter.validate(
            parameter.getValue() > 0,
            "negative or zero value is provided; should be positive"
        );
    }
   
};


#endif  // end of the include guard
