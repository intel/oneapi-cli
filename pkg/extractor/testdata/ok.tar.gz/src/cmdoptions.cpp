//==============================================================
// Copyright © 2019 Intel Corporation
//
// SPDX-License-Identifier: MIT
// =============================================================

#include <limits>
#include <cmath>

#include "cmdoptions.h"

using namespace std;


#ifdef _MSC_VER
#pragma warning (push)
#pragma warning (disable : 4355)    // 'this': used in base member initializer list
#endif

CmdParserMandelbrot::CmdParserMandelbrot(int argc, const char** argv) :
    CmdParserCommon(argc, argv),
    inputSize(
        *this,
        'n',
        "inputSize",
        "<integer>",
        "Number of total points.",
        120
    ),
    iterations(
        *this,
        'i',
        "iterations",
        "<integer>",
        "Number of kernel invocations. For each invoction, "
            "performance information will be printed. "
            "Zero is allowed: in this case no kernel invocation "
            " is performed but all other host stuff is created.",
        100
    ),
    validation(
        *this,
        'v',
        "validation",
        "",
        "Enables validation procedure on host (slow for big matrices).",
        false
    )
    
{
}

#ifdef _MSC_VER
#pragma warning (pop)
#endif


void CmdParserMandelbrot::parse ()
{
    CmdParserCommon::parse();

    // Test a small part of parameters for consistency
    // in this function. The major part of checks is placed in
    // validateParameters function. But to call it you need
    // further specialization on what OpenCL objects and their
    // capabilities are.

    /*if(arithmetic_float.isSet() && arithmetic_double.isSet())
    {
        throw CmdParser::Error(
            "Both float and double are chosen. "
            "Should be only one of them."
        );
    }

    if(!arithmetic_float.isSet() && !arithmetic_double.isSet())
    {
        throw CmdParser::Error(
            "Neither float nor double are chosen. "
            "One of them should be chosen."
        );
    }*/
}




